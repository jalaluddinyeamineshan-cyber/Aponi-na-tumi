import React from 'react';
import {OUT} from '../data';
import {FONT} from '../fonts';

export type IconName =
  | 'bottle' | 'snow' | 'window' | 'q' | 'tiffin' | 'phone' | 'phone0' | 'heart'
  | 'clock' | 'noclock' | 'cal11' | 'pin' | 'note' | 'towel' | 'car' | 'up' | 'down'
  | 'pitha' | 'route';

const S = {stroke: OUT, strokeWidth: 3.5, strokeLinejoin: 'round', strokeLinecap: 'round'} as const;

/** icon drawn in a 100x100 box. p = optional animation parameter */
export const IconG: React.FC<{name: IconName; p?: number}> = ({name, p = 0}) => {
  switch (name) {
    case 'bottle':
      return (
        <g {...S}>
          <rect x={36} y={28} width={28} height={60} rx={9} fill="#9BDCF7" />
          <rect x={41} y={12} width={18} height={16} rx={4} fill="#2F80ED" />
          <path d="M36,56 Q43,50 50,56 T64,56" fill="none" />
        </g>
      );
    case 'snow':
      return (
        <g>
          <path d="M50,8V92M14,29L86,71M14,71L86,29" stroke="#2F9BE8" strokeWidth={7} strokeLinecap="round" fill="none" />
          <circle cx={50} cy={50} r={9} fill="#fff" stroke="#2F9BE8" strokeWidth={4} />
        </g>
      );
    case 'window':
      return (
        <g {...S}>
          <rect x={16} y={14} width={68} height={72} rx={10} fill="#E8F6FD" />
          <rect x={22} y={20} width={56} height={Math.max(4, 60 * (1 - p))} fill="#8FD0F2" strokeWidth={2.5} />
          <circle cx={72} cy={78} r={4} fill={OUT} />
        </g>
      );
    case 'q':
      return (
        <text x={50} y={84} fontSize={96} fontWeight={700} textAnchor="middle" fill="#F2994A" stroke={OUT} strokeWidth={3} fontFamily={FONT}>
          ?
        </text>
      );
    case 'tiffin':
      return (
        <g {...S}>
          <rect x={20} y={62} width={60} height={22} rx={7} fill="#E57373" />
          <rect x={20} y={40} width={60} height={22} rx={7} fill="#F2C94C" />
          <rect x={20} y={18} width={60} height={22} rx={7} fill="#6FCF97" />
          <path d="M30,18 Q50,-8 70,18" fill="none" />
        </g>
      );
    case 'phone':
    case 'phone0':
      return (
        <g {...S}>
          <rect x={30} y={8} width={40} height={84} rx={10} fill="#455A64" />
          <rect x={35} y={20} width={30} height={56} rx={4} fill="#ECEFF1" />
          {[0, 1, 2, 3].map((i) => (
            <rect key={i} x={39 + i * 6} y={66 - i * 7} width={4} height={8 + i * 7} fill={name === 'phone' ? '#27AE60' : '#B0BEC5'} stroke="none" />
          ))}
          {name === 'phone0' && <path d="M38,28 L62,56 M62,28 L38,56" stroke="#EB5757" strokeWidth={6} />}
        </g>
      );
    case 'heart':
      return <path d="M50,88 C8,56 14,18 36,18 C46,18 50,26 50,32 C50,26 54,18 64,18 C86,18 92,56 50,88Z" fill="#EB5757" {...S} />;
    case 'clock':
    case 'noclock':
      return (
        <g {...S}>
          <circle cx={50} cy={50} r={38} fill="#fff" />
          <path d="M50,16V23M50,77V84M16,50H23M77,50H84" />
          <line x1={50} y1={50} x2={50} y2={22} transform={`rotate(${p * 360} 50 50)`} />
          <line x1={50} y1={50} x2={50} y2={33} transform={`rotate(${p * 30} 50 50)`} />
          {name === 'noclock' && <path d="M14,14 L86,86" stroke="#EB5757" strokeWidth={9} />}
        </g>
      );
    case 'cal11':
      return (
        <g {...S}>
          <rect x={10} y={18} width={80} height={72} rx={12} fill="#fff" />
          <path d="M10,30 Q10,18 22,18 H78 Q90,18 90,30 V44 H10Z" fill="#EB5757" />
          <path d="M32,10V26M68,10V26" strokeWidth={6} />
          <text x={50} y={80} fontSize={38} fontWeight={700} textAnchor="middle" fill={OUT} stroke="none" fontFamily={FONT}>
            ১১
          </text>
        </g>
      );
    case 'pin':
      return (
        <g {...S}>
          <path d="M50,92 C16,58 18,14 50,14 C82,14 84,58 50,92Z" fill="#EB5757" />
          <circle cx={50} cy={42} r={11} fill="#fff" />
        </g>
      );
    case 'note':
      return (
        <g {...S}>
          <path d="M38,72 V22 L74,14 V62" fill="none" strokeWidth={6} />
          <ellipse cx={30} cy={74} rx={13} ry={10} fill="#9B51E0" />
          <ellipse cx={66} cy={64} rx={13} ry={10} fill="#9B51E0" />
        </g>
      );
    case 'towel':
      return (
        <g {...S}>
          <rect x={10} y={28} width={80} height={44} rx={8} fill="#F2994A" />
          <path d="M28,28V72M72,28V72" stroke="#fff" strokeWidth={5} />
        </g>
      );
    case 'car':
      return (
        <g {...S}>
          <path d="M8,62 L14,46 Q18,38 28,38 L70,38 Q80,38 86,50 L92,62Z" fill="#EB5757" />
          <rect x={6} y={58} width={88} height={16} rx={6} fill="#EB5757" />
          <path d="M32,42 L68,42 L78,54 L24,54Z" fill="#CDEBFA" />
          <circle cx={28} cy={76} r={10} fill="#333" />
          <circle cx={72} cy={76} r={10} fill="#333" />
        </g>
      );
    case 'up':
      return <path d="M50,12 L84,56 H62 V88 H38 V56 H16Z" fill="#27AE60" {...S} />;
    case 'down':
      return <path d="M50,12 L84,56 H62 V88 H38 V56 H16Z" fill="#EB5757" transform="rotate(180 50 50)" {...S} />;
    case 'pitha':
      return (
        <g {...S}>
          <ellipse cx={50} cy={54} rx={38} ry={26} fill="#F5E6C8" />
          <path d="M24,52 Q50,34 76,52" fill="none" />
          <path d="M34,64 Q50,72 66,64" fill="none" />
        </g>
      );
    case 'route':
      return (
        <g fill="none" strokeLinecap="round">
          <path d="M12,82 L34,52 L54,72 L86,24" stroke="#2F80ED" strokeWidth={8} strokeDasharray="2 14" />
          <circle cx={12} cy={82} r={8} fill="#27AE60" stroke={OUT} strokeWidth={3} />
          <circle cx={86} cy={24} r={8} fill="#EB5757" stroke={OUT} strokeWidth={3} />
        </g>
      );
    default:
      return null;
  }
};

export const Icon: React.FC<{name: IconName; size: number; p?: number; style?: React.CSSProperties}> = ({name, size, p, style}) => (
  <svg viewBox="0 0 100 100" width={size} height={size} style={{overflow: 'visible', ...style}}>
    <IconG name={name} p={p} />
  </svg>
);
