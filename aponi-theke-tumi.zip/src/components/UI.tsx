import React from 'react';
import {useCurrentFrame} from 'remotion';
import {CUES, FPS, H, HIDE, OUT, Range, W} from '../data';
import {FONT} from '../fonts';
import {inR, Rich, sp, vis} from '../util';
import {Icon, IconName} from './Icons';

/** Bottom caption, floating over the full-screen scene. Hidden while a bubble/card is visible. */
export const Caption: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  if (HIDE.some((r) => inR(t, r))) return null;
  const c = CUES.find(([s, e]) => t >= s && t < e);
  if (!c) return null;
  const [s, , text] = c;
  const k = sp(t, s, {damping: 14, mass: 0.5});
  const len = text.replace(/\*/g, '').length;
  const fs = Math.max(44, Math.min(62, Math.floor(880 / (len * 0.5))));
  return (
    <div
      style={{
        position: 'absolute', left: 0, right: 0, bottom: 150, display: 'flex', justifyContent: 'center',
        transform: `translateY(${(1 - k) * 40}px)`, opacity: Math.min(1, (t - s) / 0.1),
      }}
    >
      <div
        style={{
          background: 'rgba(18,22,34,0.8)', color: '#fff', fontSize: fs, fontWeight: 700, fontFamily: FONT,
          padding: '16px 40px', borderRadius: 44, whiteSpace: 'nowrap', boxShadow: '0 8px 24px rgba(0,0,0,.35)',
        }}
      >
        <Rich text={text} />
      </div>
    </div>
  );
};

/** Speech bubble: tail tip at (tx,ty) pointing to the speaker's head */
export const Bubble: React.FC<{
  t: number; r: Range; tx: number; ty: number; text: string; w?: number; hl?: string; bg?: string;
}> = ({t, r, tx, ty, text, w = 800, hl = '#E5484D', bg = '#fff'}) => {
  if (!inR(t, r)) return null;
  const k = sp(t, r[0], {damping: 11, mass: 0.5});
  const left = Math.min(W - w - 40, Math.max(40, tx - w / 2));
  return (
    <div
      style={{
        position: 'absolute', left: 0, top: 0, width: W, height: H, opacity: vis(t, r, 0.1),
        transform: `scale(${0.6 + 0.4 * k})`, transformOrigin: `${tx}px ${ty}px`,
      }}
    >
      <div
        style={{
          position: 'absolute', left, bottom: H - (ty - 64), width: w, boxSizing: 'border-box',
          padding: '26px 34px', background: bg, border: `4px solid ${OUT}`, borderRadius: 44,
          fontSize: 56, fontWeight: 700, lineHeight: 1.35, textAlign: 'center', color: OUT, fontFamily: FONT,
          boxShadow: '0 10px 0 rgba(0,0,0,.12)',
        }}
      >
        <Rich text={text} hl={hl} />
      </div>
      <svg style={{position: 'absolute', left: tx - 45, top: ty - 66}} width={90} height={70} viewBox="0 0 90 70">
        <path d="M8,0 L45,64 L82,0" fill={bg} stroke={OUT} strokeWidth={4} strokeLinejoin="round" />
        <line x1={10} y1={0} x2={80} y2={0} stroke={bg} strokeWidth={10} />
      </svg>
    </div>
  );
};

/** Bold stamp-style keyword badge */
export const Stamp: React.FC<{
  t: number; r: Range; x: number; y: number; text: string; color: string; rot?: number; size?: number;
}> = ({t, r, x, y, text, color, rot = -6, size = 96}) => {
  if (!inR(t, r)) return null;
  const k = sp(t, r[0], {damping: 9, mass: 0.5});
  return (
    <div
      style={{
        position: 'absolute', left: x, top: y, whiteSpace: 'nowrap', fontFamily: FONT, fontWeight: 700,
        fontSize: size, color, background: 'rgba(255,255,255,.95)', border: `10px solid ${color}`,
        borderRadius: 28, padding: '14px 46px', opacity: vis(t, r, 0.1) * Math.min(1, k * 3),
        transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${2.4 - 1.4 * k})`,
      }}
    >
      {text}
    </div>
  );
};

/** Pinned note card (icon + text) */
export const NoteCard: React.FC<{
  t: number; r: Range; x: number; y: number; text: string; icon?: IconName; iconP?: number;
  w?: number; rot?: number; bg?: string; fs?: number;
}> = ({t, r, x, y, text, icon, iconP, w = 800, rot = -3, bg = '#FFF3B8', fs = 64}) => {
  if (!inR(t, r)) return null;
  const k = sp(t, r[0], {damping: 11, mass: 0.6});
  return (
    <div
      style={{
        position: 'absolute', left: x - w / 2, top: y, width: w, boxSizing: 'border-box', padding: '54px 36px 36px',
        background: bg, border: `4px solid ${OUT}`, borderRadius: 28, textAlign: 'center', fontFamily: FONT,
        fontWeight: 700, fontSize: fs, lineHeight: 1.3, color: OUT, boxShadow: '0 14px 0 rgba(0,0,0,.14)',
        opacity: vis(t, r, 0.12), transform: `translateY(-50%) rotate(${rot}deg) scale(${k})`,
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12,
      }}
    >
      <div style={{position: 'absolute', top: -20, left: w / 2 - 20, width: 40, height: 40, borderRadius: 20, background: '#E5484D', border: `4px solid ${OUT}`}} />
      {icon && <Icon name={icon} size={150} p={iconP} />}
      <div><Rich text={text} hl="#E5484D" /></div>
    </div>
  );
};

export const Pill: React.FC<{t: number; r: Range; x: number; y: number; text: string; color?: string; size?: number}> = ({
  t, r, x, y, text, color = '#F2994A', size = 52,
}) => {
  if (!inR(t, r)) return null;
  const k = sp(t, r[0], {damping: 10, mass: 0.5});
  return (
    <div
      style={{
        position: 'absolute', left: x, top: y, whiteSpace: 'nowrap', fontFamily: FONT, fontWeight: 700, fontSize: size,
        color: '#fff', background: color, border: `4px solid ${OUT}`, borderRadius: 60, padding: '10px 40px',
        opacity: vis(t, r, 0.1), transform: `translate(-50%,-50%) scale(${k})`,
      }}
    >
      {text}
    </div>
  );
};

/** Animated floating icon (pop-up, bob, optional pulse) */
export const FloatIcon: React.FC<{
  t: number; r: Range; x: number; y: number; name: IconName; size?: number; rot?: number; p?: number;
  bob?: number; pulse?: boolean;
}> = ({t, r, x, y, name, size = 160, rot = 0, p, bob = 8, pulse = false}) => {
  if (!inR(t, r)) return null;
  const k = sp(t, r[0], {damping: 9, mass: 0.5});
  const sc = k * (pulse ? 1 + 0.07 * Math.sin(t * 8) : 1);
  return (
    <div
      style={{
        position: 'absolute', left: x - size / 2, top: y - size / 2 + Math.sin(t * 3 + x) * bob, width: size, height: size,
        opacity: vis(t, r, 0.12), transform: `scale(${sc}) rotate(${rot}deg)`,
      }}
    >
      <Icon name={name} size={size} p={p} />
    </div>
  );
};

/** Icons rising & fading from a point (hearts, music notes ...) */
export const Burst: React.FC<{t: number; s: number; x: number; y: number; name: IconName; n?: number; dur?: number}> = ({
  t, s, x, y, name, n = 7, dur = 2.2,
}) => (
  <>
    {Array.from({length: n}).map((_, i) => {
      const d = t - s - i * 0.18;
      if (d < 0 || d > dur) return null;
      const size = 60 + (i % 3) * 26;
      return (
        <div
          key={i}
          style={{
            position: 'absolute', left: x + Math.sin(i * 2.3) * 120 + Math.sin(d * 3 + i) * 20 - size / 2,
            top: y - d * 260 - size / 2, opacity: Math.min(1, d * 5) * Math.max(0, 1 - d / dur),
            transform: `scale(${0.6 + 0.4 * Math.min(1, d * 4)}) rotate(${Math.sin(i) * 20}deg)`,
          }}
        >
          <Icon name={name} size={size} />
        </div>
      );
    })}
  </>
);
