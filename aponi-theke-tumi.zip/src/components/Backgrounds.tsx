import React from 'react';
import {AbsoluteFill} from 'remotion';
import {H, OUT, W} from '../data';
import {FONT} from '../fonts';
import {kf} from '../util';

const Full: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
    {children}
  </svg>
);

const Gradient: React.FC<{a: string; b: string}> = ({a, b}) => (
  <div style={{position: 'absolute', inset: 0, background: `linear-gradient(${a},${b} 60%)`}} />
);

/** clean motion-graphics background with soft vignette */
export const SoftBG: React.FC<{a?: string; b?: string}> = ({a = '#FFF8EA', b = '#FFE6C7'}) => (
  <AbsoluteFill>
    <Gradient a={a} b={b} />
    <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(80,40,0,.22) 100%)'}} />
  </AbsoluteFill>
);

/** car interior: scenery + roof + pillars + seats (draw characters after this) */
export const CarBack: React.FC<{t: number; out: 'city' | 'highway' | 'tea'}> = ({t, out}) => {
  const sky = out === 'tea' ? ['#A8DDB5', '#F1F8DD'] : ['#8CC8F0', '#EAF6FF'];
  const grass = out === 'tea' ? '#6DB872' : '#8CC77E';
  const items = [0, 1, 2, 3, 4, 5].map((i) => {
    const p = (t * 0.35 + i / 6) % 1;
    return {i, q: p * p};
  });
  return (
    <AbsoluteFill>
      <Gradient a={sky[0]} b={sky[1]} />
      <Full>
        <path d="M0,830 Q180,700 380,790 T760,770 T1080,810 V900 H0Z" fill={out === 'tea' ? '#5EA86B' : '#7DB88A'} />
        <rect x={0} y={860} width={W} height={700} fill={grass} />
        <polygon points="505,860 575,860 1000,1560 80,1560" fill="#5B6470" />
        {items.map(({i, q}) => (
          <rect key={'d' + i} x={540 - (2 + q * 26) / 2} y={860 + q * 640} width={2 + q * 26} height={6 + q * 90} fill="#F5F5F5" />
        ))}
        {items.map(({i, q}) =>
          [-1, 1].map((sd) => {
            const px = 540 + sd * (110 + q * 720);
            const py = 870 + q * 600;
            const sc = 0.15 + q * 1.5;
            return (
              <g key={`t${i}${sd}`} transform={`translate(${px} ${py}) scale(${sc})`}>
                {out === 'tea' ? (
                  <>
                    <ellipse cx={0} cy={-20} rx={80} ry={36} fill="#2E8B4E" />
                    <ellipse cx={-10} cy={-34} rx={56} ry={22} fill="#43A862" />
                  </>
                ) : (
                  <>
                    <rect x={-6} y={-80} width={12} height={80} fill="#7A5230" />
                    <circle cx={0} cy={-110} r={48} fill="#3E8E4A" />
                  </>
                )}
              </g>
            );
          }),
        )}
        {/* roof, pillars, mirror, seats */}
        <path d="M0,0 H1080 V210 Q540,300 0,210Z" fill="#2E3846" />
        <polygon points="0,200 190,200 70,1500 0,1500" fill="#2E3846" />
        <polygon points="1080,200 890,200 1010,1500 1080,1500" fill="#2E3846" />
        <rect x={430} y={190} width={220} height={64} rx={22} fill="#1D232C" />
        <rect x={150} y={940} width={300} height={560} rx={120} fill="#59657A" stroke={OUT} strokeWidth={4} />
        <rect x={630} y={940} width={300} height={560} rx={120} fill="#59657A" stroke={OUT} strokeWidth={4} />
      </Full>
    </AbsoluteFill>
  );
};

/** dashboard + steering wheel (draw after characters) */
export const CarFront: React.FC = () => (
  <Full>
    <path d="M0,1330 Q540,1280 1080,1330 V1920 H0Z" fill="#323D4C" />
    <path d="M0,1330 Q540,1280 1080,1330" stroke="#4A5A70" strokeWidth={14} fill="none" />
    <rect x={400} y={1470} width={280} height={56} rx={28} fill="#1F2833" />
    {[0, 1, 2, 3, 4, 5].map((i) => (
      <line key={i} x1={440 + i * 40} y1={1478} x2={440 + i * 40} y2={1518} stroke="#4A5A70" strokeWidth={5} />
    ))}
    <rect x={470} y={1570} width={140} height={90} rx={14} fill="#16202B" />
    <ellipse cx={300} cy={1450} rx={175} ry={72} fill="none" stroke="#1B1F26" strokeWidth={26} />
    <ellipse cx={300} cy={1450} rx={52} ry={26} fill="#2C323C" />
  </Full>
);

export const Rain: React.FC<{t: number; a: number}> = ({t, a}) => (
  <AbsoluteFill style={{opacity: a}}>
    <div style={{position: 'absolute', inset: 0, background: 'rgba(25,35,60,.28)'}} />
    <Full>
      {Array.from({length: 52}).map((_, i) => {
        const x = ((i * 137) % 1180) - 50;
        const y = ((t * 1700 + i * 251) % 2200) - 150;
        return <line key={i} x1={x} y1={y} x2={x - 26} y2={y + 84} stroke="rgba(235,245,255,.6)" strokeWidth={4} strokeLinecap="round" />;
      })}
    </Full>
  </AbsoluteFill>
);

const Hills: React.FC<{top: number; c1: string; c2: string; c3: string}> = ({top, c1, c2, c3}) => (
  <>
    <path d={`M0,${top} Q250,${top - 150} 520,${top - 40} T1080,${top - 60} V${top + 500} H0Z`} fill={c1} />
    <path d={`M0,${top + 70} Q300,${top - 60} 700,${top + 40} T1080,${top + 10} V${top + 600} H0Z`} fill={c2} />
    {[0, 1, 2, 3, 4, 5, 6].map((i) => (
      <path key={i} d={`M0,${top + 140 + i * 46} Q540,${top + 70 + i * 46 - 60} 1080,${top + 150 + i * 46}`} stroke={c3} strokeWidth={9} fill="none" opacity={0.8} />
    ))}
  </>
);

/** scene 4: stuck car on muddy slope. sink 0..1 = how deep the front wheel is. */
export const StuckCarBG: React.FC<{t: number; sink: number; carDx: number; heads: boolean}> = ({t, sink, carDx, heads}) => {
  const tilt = 6 * sink;
  return (
    <AbsoluteFill>
      <Gradient a="#8FA0B0" b="#C9D4DC" />
      <Full>
        <Hills top={780} c1="#6A9A78" c2="#5E9468" c3="#47804F" />
        <path d="M0,1470 Q300,1440 600,1470 T1080,1450 V1920 H0Z" fill="#7A5A3A" />
        <path d="M0,1470 Q300,1440 600,1470 T1080,1450" stroke="#9A7A55" strokeWidth={14} fill="none" />
        <ellipse cx={200} cy={1660} rx={160} ry={34} fill="#6A4C30" />
        <ellipse cx={760} cy={1780} rx={220} ry={40} fill="#6A4C30" />
        <g transform={`translate(${carDx} 0) rotate(${tilt} 560 1452)`}>
          <rect x={420} y={1240} width={620} height={130} rx={40} fill="#D84A4A" stroke={OUT} strokeWidth={4} />
          <path d="M520,1240 L580,1130 Q600,1110 640,1110 L860,1110 Q900,1110 925,1140 L965,1240Z" fill="#D84A4A" stroke={OUT} strokeWidth={4} />
          <path d="M595,1230 L630,1140 L735,1140 L735,1230Z M755,1230 L755,1140 L865,1140 Q890,1140 905,1160 L935,1230Z" fill="#CFEBFA" stroke={OUT} strokeWidth={3} />
          {heads && (
            <>
              <circle cx={680} cy={1185} r={26} fill="#E6B68C" stroke={OUT} strokeWidth={3} />
              <path d="M654,1182 Q680,1150 706,1182Z" fill="#1D1D1D" />
              <circle cx={810} cy={1185} r={26} fill="#EDBF98" stroke={OUT} strokeWidth={3} />
              <path d="M784,1190 Q810,1150 836,1190 L836,1215 L784,1215Z" fill="#1B1B1B" />
            </>
          )}
          <circle cx={1030} cy={1290} r={15} fill="#FFE08A" stroke={OUT} strokeWidth={3} />
          <rect x={410} y={1330} width={30} height={30} rx={8} fill="#999" stroke={OUT} strokeWidth={3} />
          {[560, 900].map((cx) => (
            <g key={cx}>
              <circle cx={cx} cy={1390} r={64} fill="#2B2B2B" stroke={OUT} strokeWidth={4} />
              <circle cx={cx} cy={1390} r={28} fill="#BDBDBD" stroke={OUT} strokeWidth={3} />
            </g>
          ))}
        </g>
        <ellipse cx={920 + carDx} cy={1466 + 12 * sink} rx={130} ry={Math.max(10, 50 * sink)} fill="#7A5A3A" />
        <ellipse cx={920 + carDx} cy={1466 + 12 * sink} rx={130} ry={Math.max(6, 50 * sink)} fill="none" stroke="#9A7A55" strokeWidth={8} />
        <circle cx={870 + carDx} cy={1450 - Math.abs(Math.sin(t * 9)) * 30 * sink} r={9} fill="#7A5A3A" opacity={sink} />
      </Full>
    </AbsoluteFill>
  );
};

/** after-rain tea garden (scene 5) */
export const TeaBG: React.FC = () => (
  <AbsoluteFill>
    <Gradient a="#BFE3F5" b="#FFF1D6" />
    <Full>
      <circle cx={860} cy={420} r={90} fill="#FFE9A8" opacity={0.85} />
      <Hills top={760} c1="#7CBF86" c2="#5FAE70" c3="#3F9158" />
      <path d="M0,1560 Q300,1530 600,1560 T1080,1545 V1920 H0Z" fill="#8A6A48" />
      <ellipse cx={240} cy={1790} rx={200} ry={36} fill="#A9C9D6" opacity={0.7} />
      <ellipse cx={820} cy={1840} rx={230} ry={40} fill="#A9C9D6" opacity={0.7} />
    </Full>
  </AbsoluteFill>
);

/** tea stall — behind Karim */
export const StallBack: React.FC = () => (
  <AbsoluteFill>
    <Gradient a="#BFE3F5" b="#FFF1D6" />
    <Full>
      <Hills top={540} c1="#7CBF86" c2="#5FAE70" c3="#3F9158" />
      <rect x={0} y={700} width={W} height={720} fill="#C79B6D" />
      {Array.from({length: 11}).map((_, i) => (
        <line key={i} x1={i * 100} y1={700} x2={i * 100} y2={1420} stroke="#A87C50" strokeWidth={4} />
      ))}
      <rect x={20} y={640} width={34} height={800} fill="#7A5230" stroke={OUT} strokeWidth={4} />
      <rect x={1026} y={640} width={34} height={800} fill="#7A5230" stroke={OUT} strokeWidth={4} />
      {/* awning */}
      {Array.from({length: 9}).map((_, i) => (
        <path key={i} d={`M${i * 120},520 H${i * 120 + 120} L${i * 120 + 128},700 H${i * 120 - 8}Z`} fill={i % 2 ? '#fff' : '#D9534F'} stroke={OUT} strokeWidth={3} />
      ))}
      {/* shelf + jars */}
      <rect x={70} y={980} width={520} height={18} fill="#7A5230" stroke={OUT} strokeWidth={3} />
      {[0, 1, 2, 3, 4].map((i) => (
        <rect key={i} x={90 + i * 100} y={900} width={70} height={80} rx={12} fill={['#E57373', '#F2C94C', '#6FCF97', '#64B5F6', '#BA68C8'][i]} stroke={OUT} strokeWidth={3} />
      ))}
      {/* sign */}
      <path d="M760,700 L780,790 M1000,700 L980,790" stroke={OUT} strokeWidth={4} />
      <rect x={720} y={790} width={300} height={160} rx={18} fill="#2F6F4F" stroke={OUT} strokeWidth={5} />
      <text x={870} y={908} fontSize={120} fontWeight={700} textAnchor="middle" fill="#fff" fontFamily={FONT}>
        চা
      </text>
    </Full>
  </AbsoluteFill>
);

/** stall counter + kettle with steam — drawn in front of Karim */
export const StallFront: React.FC<{t: number}> = ({t}) => (
  <Full>
    <rect x={0} y={1400} width={W} height={520} fill="#9A6B3F" stroke={OUT} strokeWidth={4} />
    <rect x={0} y={1380} width={W} height={40} fill="#B8834F" stroke={OUT} strokeWidth={4} />
    {Array.from({length: 7}).map((_, i) => (
      <line key={i} x1={i * 180} y1={1420} x2={i * 180} y2={1920} stroke="#7B5230" strokeWidth={4} />
    ))}
    <g transform="translate(610 1380)">
      <path d="M-50,0 L-40,-90 Q0,-120 40,-90 L50,0Z" fill="#CFD8DC" stroke={OUT} strokeWidth={4} />
      <path d="M40,-70 L90,-100" stroke={OUT} strokeWidth={8} />
      {[0, 1, 2].map((i) => {
        const p = (t * 0.6 + i / 3) % 1;
        return <circle key={i} cx={90 + Math.sin(p * 8 + i) * 12} cy={-110 - p * 140} r={14 + p * 18} fill="#fff" opacity={0.75 * (1 - p)} />;
      })}
    </g>
    {[380, 450].map((x) => (
      <rect key={x} x={x} y={1330} width={40} height={50} rx={8} fill="#FFE9B8" stroke={OUT} strokeWidth={3} />
    ))}
  </Full>
);

export const camZoom = (t: number, keys: number[], vals: number[]) => kf(t, keys, vals, true);
