import React from 'react';
import {OUT, Range} from '../data';
import {inR} from '../util';

export type Expr = 'neutral' | 'smile' | 'worried' | 'laugh' | 'surprised' | 'sheepish' | 'confident';
export type Who = 'yamin' | 'jharna' | 'karim';

export type CharProps = {
  who: Who;
  x: number; // feet center (px)
  y: number; // feet y (px)
  t: number; // absolute seconds
  s?: number;
  expr?: Expr;
  talk?: boolean | Range[];
  armL?: number; // viewer-left arm: + = swing outward (left)
  armR?: number; // viewer-right arm: + = swing outward (right)
  sit?: boolean; // upper body only
  lean?: number;
  mud?: number; // 0..1
  flip?: boolean;
  look?: number; // -1..1 pupils
  shake?: number;
  handL?: React.ReactNode;
  handR?: React.ReactNode;
  opacity?: number;
};

const LOOKS = {
  yamin: {skin: '#E6B68C', hair: '#1D1D1D', top: '#9FCBF0'},
  jharna: {skin: '#EDBF98', hair: '#1B1B1B', top: '#1E6B3C'},
  karim: {skin: '#D6A074', hair: '#9A9A9A', top: '#F3EBBF'},
};

const BROW: Record<Expr, [string, string]> = {
  neutral: ['M-58,-492 L-16,-492', 'M16,-492 L58,-492'],
  smile: ['M-58,-490 Q-37,-502 -16,-492', 'M16,-492 Q37,-502 58,-490'],
  worried: ['M-58,-482 L-16,-500', 'M16,-500 L58,-482'],
  laugh: ['M-58,-494 Q-37,-508 -16,-494', 'M16,-494 Q37,-508 58,-494'],
  surprised: ['M-58,-506 Q-37,-522 -16,-506', 'M16,-506 Q37,-522 58,-506'],
  sheepish: ['M-58,-484 L-16,-498', 'M16,-498 L58,-484'],
  confident: ['M-58,-496 L-16,-488', 'M16,-488 L58,-496'],
};

const MOUTH: Record<Expr, string> = {
  neutral: 'M-20,-390 L20,-390',
  smile: 'M-30,-398 Q0,-368 30,-398',
  worried: 'M-24,-382 Q0,-402 24,-382',
  sheepish: 'M-26,-390 Q0,-374 26,-398',
  confident: 'M-30,-396 Q0,-372 30,-396',
  laugh: '',
  surprised: '',
};

const ln = {stroke: OUT, strokeWidth: 2.6, strokeLinejoin: 'round', strokeLinecap: 'round'} as const;
const MUD = '#6B4A2B';

export const Character: React.FC<CharProps> = ({
  who, x, y, t, s = 1, expr = 'neutral', talk = false, armL = 4, armR = 4, sit = false, lean = 0, mud = 0,
  flip = false, look = 0, shake = 0, handL, handR, opacity = 1,
}) => {
  const L = LOOKS[who];
  const talking = talk === true || (Array.isArray(talk) && talk.some((r) => inR(t, r)));
  const shape = talking ? Math.floor(Math.abs(Math.sin(t * 17.3 + who.length)) * 3) : -1;
  const closedEyes = ((t + who.length * 0.7) % 3.6) < 0.12 || expr === 'laugh';
  const fy = Math.sin(t * 2.2 + who.length) * 5;
  const jx = shake * Math.sin(t * 90);
  const jy = shake * 0.6 * Math.cos(t * 77);

  const arm = (side: -1 | 1, a: number, hand?: React.ReactNode) => (
    <g transform={`translate(${side * 100},-330) rotate(${side === -1 ? a : -a})`}>
      <rect x={-17} y={-8} width={34} height={185} rx={17} fill={who === 'yamin' ? L.top : L.skin} {...ln} />
      {who === 'jharna' && (
        <>
          <rect x={-17} y={-8} width={34} height={70} rx={17} fill={L.top} {...ln} />
          <rect x={-19} y={146} width={38} height={9} rx={4} fill="#E3B23C" {...ln} />
          <rect x={-19} y={160} width={38} height={9} rx={4} fill="#E3B23C" {...ln} />
        </>
      )}
      <circle cx={0} cy={190} r={22} fill={L.skin} {...ln} />
      {hand && <g transform="translate(0,190)">{hand}</g>}
    </g>
  );

  let mouth: React.ReactNode;
  if (expr === 'laugh') {
    mouth = (
      <>
        <path d="M-44,-412 Q0,-330 44,-412 Z" fill="#7B2A2A" {...ln} />
        <path d="M-24,-372 Q0,-392 24,-372 Q0,-356 -24,-372Z" fill="#E87A7A" />
      </>
    );
  } else if (talking) {
    mouth =
      shape === 0 ? (
        <path d="M-18,-392 Q0,-388 18,-392" fill="none" {...ln} />
      ) : shape === 1 ? (
        <ellipse cx={0} cy={-392} rx={16} ry={10} fill="#7B2A2A" {...ln} />
      ) : (
        <ellipse cx={0} cy={-388} rx={22} ry={20} fill="#7B2A2A" {...ln} />
      );
  } else if (expr === 'surprised') {
    mouth = <ellipse cx={0} cy={-388} rx={16} ry={22} fill="#7B2A2A" {...ln} />;
  } else {
    mouth = <path d={MOUTH[expr]} fill="none" {...ln} />;
  }

  const eye = (cx: number) =>
    closedEyes ? (
      <path d={`M${cx - 17},-442 Q${cx},-462 ${cx + 17},-442`} fill="none" {...ln} strokeWidth={4} />
    ) : (
      <>
        <ellipse cx={cx} cy={-445} rx={17} ry={20} fill="#fff" {...ln} />
        <circle cx={cx + look * 6} cy={-443} r={8} fill="#111" />
      </>
    );

  return (
    <svg
      viewBox="-220 -620 440 660"
      width={440 * s}
      height={660 * s}
      style={{position: 'absolute', left: x - 220 * s, top: y - 620 * s, overflow: 'visible', opacity, transform: flip ? 'scaleX(-1)' : undefined}}
    >
      <defs>
        <pattern id="lungi" width="28" height="28" patternUnits="userSpaceOnUse">
          <rect width="28" height="28" fill="#EDEDED" />
          <path d="M0,0H28M0,0V28" stroke="#8F9AA3" strokeWidth="4" />
        </pattern>
      </defs>
      <g transform={`translate(${jx},${fy + jy}) rotate(${lean})`}>
        {/* back hair (Jharna) */}
        {who === 'jharna' && (
          <path d="M-94,-450 C-124,-330 -112,-282 -66,-278 L66,-278 C112,-282 124,-330 94,-450Z" fill={L.hair} {...ln} />
        )}

        {/* lower body */}
        {!sit && who === 'yamin' && (
          <>
            <rect x={-72} y={-180} width={58} height={176} rx={29} fill="#4B515A" {...ln} />
            <rect x={14} y={-180} width={58} height={176} rx={29} fill="#4B515A" {...ln} />
            <ellipse cx={-46} cy={-4} rx={42} ry={15} fill="#2B2B2B" {...ln} />
            <ellipse cx={46} cy={-4} rx={42} ry={15} fill="#2B2B2B" {...ln} />
          </>
        )}
        {!sit && who === 'jharna' && (
          <>
            <path d="M-94,-175 L94,-175 L112,-8 Q0,10 -112,-8Z" fill={L.top} {...ln} />
            <path d="M-40,-170 L-48,-12 M10,-170 L12,-10 M55,-170 L66,-12" {...ln} stroke="#154F2C" fill="none" />
            <path d="M-111,-18 Q0,0 111,-18" stroke="#E3B23C" strokeWidth={6} fill="none" />
            <ellipse cx={-40} cy={-3} rx={26} ry={12} fill={L.skin} {...ln} />
            <ellipse cx={40} cy={-3} rx={26} ry={12} fill={L.skin} {...ln} />
          </>
        )}
        {!sit && who === 'karim' && (
          <>
            <path d="M-96,-190 L96,-190 L106,-8 Q0,10 -106,-8Z" fill="url(#lungi)" {...ln} />
            <ellipse cx={-40} cy={-3} rx={28} ry={12} fill={L.skin} {...ln} />
            <ellipse cx={40} cy={-3} rx={28} ry={12} fill={L.skin} {...ln} />
          </>
        )}

        {/* torso + neck */}
        <rect x={-26} y={-376} width={52} height={44} fill={L.skin} {...ln} />
        <rect x={-95} y={-360} width={190} height={205} rx={52} fill={L.top} {...ln} />
        {who === 'yamin' && (
          <>
            <path d="M-30,-360 L0,-322 L30,-360 L42,-352 L0,-296 L-42,-352Z" fill="#C7E3F7" {...ln} />
            <path d="M0,-296 V-160" stroke={OUT} strokeWidth={2.6} />
            <circle cx={8} cy={-250} r={4} fill={OUT} />
            <circle cx={8} cy={-200} r={4} fill={OUT} />
          </>
        )}
        {who === 'jharna' && (
          <>
            <path d="M-70,-362 L-10,-362 L102,-200 L96,-160 L58,-160Z" fill="#2F8E57" {...ln} />
            <path d="M-50,-362 L84,-168" stroke="#E3B23C" strokeWidth={5} fill="none" />
          </>
        )}
        {who === 'karim' && (
          <>
            <path d="M-34,-360 Q0,-306 34,-360" fill={L.skin} {...ln} />
            <path d="M-100,-352 L-38,-366 L-26,-296 L-100,-282Z" fill="#C44536" {...ln} />
            <path d="M-92,-330 L-34,-340 M-92,-312 L-30,-322" stroke="#fff" strokeWidth={4} />
          </>
        )}

        {/* arms */}
        {arm(-1, armL, handL)}
        {arm(1, armR, handR)}

        {/* ears + head */}
        <circle cx={-88} cy={-435} r={16} fill={L.skin} {...ln} />
        <circle cx={88} cy={-435} r={16} fill={L.skin} {...ln} />
        <ellipse cx={0} cy={-440} rx={88} ry={94} fill={L.skin} {...ln} />

        {/* hair */}
        {who === 'yamin' && (
          <path d="M-90,-448 C-98,-548 98,-548 90,-448 C76,-496 40,-506 0,-498 C-40,-506 -76,-496 -90,-448Z" fill={L.hair} {...ln} />
        )}
        {who === 'jharna' && (
          <path d="M-92,-452 C-92,-546 92,-546 92,-452 C72,-500 22,-508 0,-494 C-30,-508 -72,-498 -92,-452Z" fill={L.hair} {...ln} />
        )}
        {who === 'karim' && (
          <>
            <ellipse cx={-84} cy={-452} rx={12} ry={26} fill={L.hair} {...ln} />
            <ellipse cx={84} cy={-452} rx={12} ry={26} fill={L.hair} {...ln} />
            <path d="M-30,-520 Q-10,-534 14,-528" stroke="#fff" strokeWidth={6} fill="none" strokeLinecap="round" opacity={0.7} />
          </>
        )}

        {/* face */}
        {eye(-36)}
        {eye(36)}
        <path d={BROW[expr][0]} fill="none" {...ln} strokeWidth={5} stroke={who === 'karim' ? '#777' : OUT} />
        <path d={BROW[expr][1]} fill="none" {...ln} strokeWidth={5} stroke={who === 'karim' ? '#777' : OUT} />
        {(expr === 'smile' || expr === 'laugh' || expr === 'confident') && (
          <>
            <circle cx={-62} cy={-410} r={13} fill="#F29A8E" opacity={0.55} />
            <circle cx={62} cy={-410} r={13} fill="#F29A8E" opacity={0.55} />
          </>
        )}
        <path d="M-5,-432 Q0,-424 6,-432" fill="none" {...ln} />
        {who === 'yamin' && (
          <path d="M-62,-404 C-50,-350 50,-350 62,-404 C34,-390 -34,-390 -62,-404Z" fill={L.hair} opacity={0.3} />
        )}
        {mouth}
        {who === 'yamin' && (
          <g fill="none" stroke="#111" strokeWidth={4.5}>
            <rect x={-64} y={-468} width={54} height={46} rx={14} />
            <rect x={10} y={-468} width={54} height={46} rx={14} />
            <path d="M-10,-452 L10,-452" />
          </g>
        )}
        {who === 'jharna' && <circle cx={0} cy={-476} r={6} fill="#111" />}
        {who === 'karim' && (
          <>
            <path d="M-40,-410 Q-20,-428 0,-414 Q20,-428 40,-410 Q20,-398 0,-406 Q-20,-398 -40,-410Z" fill={L.hair} {...ln} />
            <path d="M-62,-452 Q-70,-440 -64,-430 M62,-452 Q70,-440 64,-430" stroke="#9a6b47" strokeWidth={2.5} fill="none" />
          </>
        )}

        {/* mud */}
        {mud > 0 && (
          <g fill={MUD} opacity={mud * 0.88}>
            <circle cx={-42} cy={-472} r={13} />
            <circle cx={30} cy={-402} r={11} />
            <circle cx={3} cy={-430} r={10} />
            <circle cx={58} cy={-455} r={9} />
            <circle cx={-60} cy={-415} r={8} />
            {who === 'jharna' && (
              <>
                <circle cx={-70} cy={-500} r={16} />
                <circle cx={40} cy={-520} r={14} />
              </>
            )}
            <circle cx={-50} cy={-300} r={26} />
            <circle cx={60} cy={-250} r={30} />
            <circle cx={-20} cy={-200} r={22} />
            <circle cx={70} cy={-330} r={16} />
            <circle cx={-75} cy={-215} r={18} />
            {!sit && (
              <>
                <circle cx={-50} cy={-60} r={28} />
                <circle cx={55} cy={-90} r={26} />
                <circle cx={0} cy={-30} r={30} />
              </>
            )}
          </g>
        )}
      </g>
    </svg>
  );
};
