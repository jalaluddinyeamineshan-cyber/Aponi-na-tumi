import React, {createContext, useContext} from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame} from 'remotion';
import {FPS, Range} from './data';

export const StartCtx = createContext(0);

/** absolute time in seconds (works inside any scene Sequence) */
export const useT = () => {
  const f = useCurrentFrame();
  return (useContext(StartCtx) + f) / FPS;
};

export const inR = (t: number, r: Range) => t >= r[0] && t < r[1];

export const sp = (
  t: number,
  s: number,
  cfg: {damping?: number; mass?: number; stiffness?: number} = {damping: 12, mass: 0.6},
) => (t < s ? 0 : spring({frame: (t - s) * FPS, fps: FPS, config: cfg}));

export const vis = (t: number, r: Range, f = 0.15) =>
  interpolate(t, [r[0], r[0] + f, r[1] - f, r[1]], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

export const kf = (t: number, times: number[], vals: number[], ease = false) =>
  interpolate(t, times, vals, {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: ease ? Easing.inOut(Easing.cubic) : undefined,
  });

export const Rich: React.FC<{text: string; hl?: string}> = ({text, hl = '#FFD54A'}) => (
  <>
    {text.split('*').map((p, i) =>
      i % 2 ? (
        <span key={i} style={{color: hl, fontWeight: 800}}>
          {p}
        </span>
      ) : (
        <span key={i}>{p}</span>
      ),
    )}
  </>
);

export const Shake: React.FC<{amp: number; children: React.ReactNode}> = ({amp, children}) => {
  const t = useT();
  return (
    <AbsoluteFill
      style={{transform: `translate(${Math.sin(t * 83) * amp}px,${Math.cos(t * 71) * amp}px)`}}
    >
      {children}
    </AbsoluteFill>
  );
};
