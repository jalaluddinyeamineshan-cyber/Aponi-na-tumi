import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {SCENES} from './data';
import {FONT} from './fonts';
import {StartCtx} from './util';
import {Caption} from './components/UI';
import {Scene1} from './scenes/Scene1';
import {Scene2} from './scenes/Scene2';
import {Scene3} from './scenes/Scene3';
import {Scene4} from './scenes/Scene4';
import {Scene5} from './scenes/Scene5';
import {Scene6} from './scenes/Scene6';
import {Scene7} from './scenes/Scene7';

const COMPS = [Scene1, Scene2, Scene3, Scene4, Scene5, Scene6, Scene7];

const FadeIn: React.FC<{children: React.ReactNode}> = ({children}) => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{opacity: interpolate(f, [0, 6], [0, 1], {extrapolateRight: 'clamp'})}}>{children}</AbsoluteFill>;
};

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: '#000', fontFamily: FONT}}>
    <Audio src={staticFile('voice.mp3')} />
    {SCENES.map((sc, i) => {
      const Comp = COMPS[i];
      return (
        <Sequence key={i} from={sc.from} durationInFrames={sc.dur}>
          <StartCtx.Provider value={sc.from}>
            <FadeIn>
              <Comp />
            </FadeIn>
          </StartCtx.Provider>
        </Sequence>
      );
    })}
    <Caption />
  </AbsoluteFill>
);
