import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {FPS, H, TOTAL, W} from './data';

export const Root: React.FC = () => (
  <Composition
    id="AponiTheke"
    component={Video}
    durationInFrames={TOTAL}
    fps={FPS}
    width={W}
    height={H}
  />
);
