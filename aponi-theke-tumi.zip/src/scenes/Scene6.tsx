import React from 'react';
import {AbsoluteFill} from 'remotion';
import {R} from '../data';
import {inR, kf, useT} from '../util';
import {Character} from '../components/Character';
import {CarBack, CarFront, StallBack, StallFront} from '../components/Backgrounds';
import {Burst, FloatIcon, NoteCard, Pill} from '../components/UI';
import {IconG} from '../components/Icons';

const SWITCH = 138.12;

export const Scene6: React.FC = () => {
  const t = useT();
  const flash = Math.max(0, 1 - Math.abs(t - SWITCH) / 0.18);
  return (
    <AbsoluteFill>
      {t < SWITCH ? <Stall t={t} /> : <CarRide t={t} />}
      <AbsoluteFill style={{background: '#fff', opacity: flash * 0.9}} />
    </AbsoluteFill>
  );
};

const Stall: React.FC<{t: number}> = ({t}) => {
  const mud = kf(t, [126.5, 129.5], [1, 0.2]);
  const yx = kf(t, [118.4, 120.4], [-300, 190], true);
  const jx = kf(t, [118.6, 120.8], [-300, 450], true);
  const walking = t < 120.8;
  const bounce = walking ? Math.abs(Math.sin(t * 10)) * 12 : 0;
  const scratch = inR(t, [133.16, 134.94]);
  const towel = t >= 125.2;
  const giggle = t > 123.5 && t < 126 ? 2 : 0;
  return (
    <AbsoluteFill>
      <StallBack />
      <Character
        who="karim" x={790} y={1650} s={1.05} t={t} expr="smile" talk={[R.s6card]} shake={giggle}
        armL={towel ? 72 : 6} armR={8} look={-0.8}
        handL={towel ? (
          <g transform="translate(-45,-25) scale(0.9)">
            <IconG name="towel" />
          </g>
        ) : undefined}
      />
      <StallFront t={t} />
      <Character
        who="yamin" x={yx} y={1820 - bounce} s={1.1} t={t} mud={mud}
        expr={scratch ? 'sheepish' : t > 123 ? 'sheepish' : 'worried'}
        armR={scratch ? 165 + Math.sin(t * 14) * 8 : 4} look={0.8}
      />
      <Character
        who="jharna" x={jx} y={1820 - bounce} s={1.1} t={t} mud={mud}
        expr={t > 134.94 ? 'smile' : t > 123 ? 'smile' : 'worried'} look={0.4}
      />
      <Pill t={t} r={R.s6badge} x={790} y={960} text="দোকানদার কাকা করিম" />
      <NoteCard t={t} r={R.s6card} x={540} y={420} text="মূল রাস্তা *মাত্র ২ মিনিট* দূরে" icon="pin" w={820} />
    </AbsoluteFill>
  );
};

const CarRide: React.FC<{t: number}> = ({t}) => {
  const arguing = t > 144.2 && t < 146.1;
  return (
    <AbsoluteFill>
      <CarBack t={t} out="tea" />
      <Character who="yamin" x={300} y={1530} s={1.3} t={t} sit mud={0.2} expr={arguing ? 'confident' : 'smile'} talk={arguing ? [[144.4, 145.0], [145.6, 146.0]] : false} look={0.7} />
      <Character who="jharna" x={780} y={1530} s={1.3} t={t} sit mud={0.2} expr={arguing ? 'confident' : 'smile'} talk={arguing ? [[144.7, 145.4], [145.9, 146.1]] : false} look={-0.6} />
      <CarFront />
      <FloatIcon t={t} r={[140.0, 151.48]} x={780} y={1190} name="tiffin" size={280} rot={Math.sin(t * 3) * 3} />
      <FloatIcon t={t} r={[142.0, 144.2]} x={540} y={1090} name="pitha" size={150} />
      <Burst t={t} s={144.2} x={540} y={900} name="note" n={6} dur={3} />
      <FloatIcon t={t} r={[146.9, 149.2]} x={880} y={500} name="clock" size={210} p={t * 3} />
      <FloatIcon t={t} r={[149.2, 151.48]} x={880} y={500} name="noclock" size={210} p={0.1} pulse />
    </AbsoluteFill>
  );
};
