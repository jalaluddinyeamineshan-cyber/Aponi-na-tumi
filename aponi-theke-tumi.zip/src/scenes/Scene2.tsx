import React from 'react';
import {AbsoluteFill} from 'remotion';
import {OUT} from '../data';
import {FONT} from '../fonts';
import {kf, sp, useT, vis} from '../util';
import {Character} from '../components/Character';
import {CarBack, CarFront, SoftBG} from '../components/Backgrounds';
import {FloatIcon} from '../components/UI';
import {Icon} from '../components/Icons';
import {R} from '../data';

const RouteCard: React.FC<{t: number}> = ({t}) => {
  if (t < R.s2route[0] || t >= R.s2route[1]) return null;
  const k = sp(t, R.s2route[0]);
  const p = Math.min(1, (t - 18.0) / 4.4);
  const chip = {fontFamily: FONT, fontWeight: 700, fontSize: 48, color: OUT} as const;
  return (
    <div
      style={{
        position: 'absolute', left: 70, top: 300, width: 940, height: 250, background: '#fff', border: `4px solid ${OUT}`,
        borderRadius: 40, boxShadow: '0 12px 0 rgba(0,0,0,.14)', opacity: vis(t, R.s2route, 0.15), transform: `scale(${k})`,
      }}
    >
      <div style={{position: 'absolute', left: 30, top: 40, textAlign: 'center', width: 190, ...chip}}>
        <Icon name="pin" size={90} />
        <div>ঢাকা</div>
      </div>
      <div style={{position: 'absolute', right: 30, top: 40, textAlign: 'center', width: 230, ...chip}}>
        <Icon name="pin" size={90} />
        <div>শ্রীমঙ্গল</div>
      </div>
      <div style={{position: 'absolute', left: 250, top: 110, width: 450, borderTop: `8px dashed #2F80ED`}} />
      <div style={{position: 'absolute', left: 250 + p * 350, top: 62}}>
        <Icon name="car" size={100} />
      </div>
    </div>
  );
};

export const Scene2: React.FC = () => {
  const t = useT();
  const calO = t < 14.9 ? 1 : Math.max(0, 1 - (t - 14.9) / 0.4);
  const winP = kf(t, [26.7, 28.4, 29.0, 29.8, 30.5], [0, 1, 1, 0, 0]);
  const ySway = Math.sin(t * 0.9) * 0.8;
  const yExpr = t > 30 ? 'sheepish' : t > 22.78 ? 'worried' : 'neutral';
  const jExpr = t > 30.5 ? 'sheepish' : t > 26.6 ? 'worried' : 'smile';
  return (
    <AbsoluteFill>
      <CarBack t={t} out="city" />
      <Character who="yamin" x={300} y={1530} s={1.3} t={t} sit expr={yExpr} look={ySway} />
      <Character who="jharna" x={780} y={1530} s={1.3} t={t} sit expr={jExpr} look={-ySway} />
      <CarFront />

      <FloatIcon t={t} r={[22.9, 26.6]} x={210} y={690} name="snow" size={150} pulse />
      <FloatIcon t={t} r={[22.9, 24.4]} x={380} y={690} name="down" size={110} />
      <FloatIcon t={t} r={[24.4, 26.6]} x={380} y={690} name="up" size={110} />
      <FloatIcon t={t} r={[26.7, 30.6]} x={780} y={690} name="window" size={170} p={winP} />
      <FloatIcon t={t} r={[30.6, 35.0]} x={540} y={640} name="q" size={170} />
      <FloatIcon t={t} r={[31.5, 35.0]} x={400} y={540} name="q" size={110} rot={-14} />
      <FloatIcon t={t} r={[32.4, 35.0]} x={690} y={540} name="q" size={110} rot={14} />
      <FloatIcon t={t} r={[36.2, 42.32]} x={540} y={1170} name="tiffin" size={300} rot={Math.sin(t * 3) * 4} />
      <RouteCard t={t} />

      {calO > 0 && (
        <AbsoluteFill style={{opacity: calO}}>
          <SoftBG a="#EAF4FF" b="#CFE6FA" />
          <div style={{position: 'absolute', left: 0, right: 0, top: 560, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20}}>
            <Icon name="cal11" size={560} style={{transform: `scale(${sp(t, 13.1)})`}} />
            <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 92, color: OUT, transform: `scale(${sp(t, 13.5)})`}}>
              বিয়ের <span style={{color: '#E5484D'}}>১১তম</span> দিন
            </div>
          </div>
        </AbsoluteFill>
      )}
    </AbsoluteFill>
  );
};
