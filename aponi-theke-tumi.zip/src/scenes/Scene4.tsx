import React from 'react';
import {AbsoluteFill} from 'remotion';
import {R} from '../data';
import {kf, Shake, useT} from '../util';
import {Character} from '../components/Character';
import {Rain, StuckCarBG} from '../components/Backgrounds';
import {Bubble, Stamp} from '../components/UI';

export const Scene4: React.FC = () => {
  const t = useT();
  const sink = kf(t, [69.9, 72.8, 80.6, 83.0], [0, 1, 1, 0]);
  const pushing = t > 74.5 && t < 82.2;
  const free = kf(t, [80.6, 83.0], [0, 1]);
  const carDx = free * 40 + (pushing ? Math.sin(t * 12) * 3 : 0);
  const mud = kf(t, [80.5, 84.5], [0, 1]);
  const rainA = kf(t, [67.0, 68.5, 91.0, 91.9], [0, 1, 1, 0.6]);
  const yx = kf(t, [73.3, 74.2], [-420, 215]);
  const jx = kf(t, [76.6, 77.6], [-420, 95]);
  const lean = pushing ? 14 + 4 * Math.sin(t * 9) : 2;
  const flash = Math.max(0, 1 - Math.abs(t - 67.15) / 0.12);
  const armsY = pushing ? [-70, 75] : [6, 6];
  const yExpr = t > 82.2 ? 'worried' : 'neutral';
  return (
    <AbsoluteFill>
      <Shake amp={t > 67 ? (pushing ? 4 : 1.5) : 0}>
        <StuckCarBG t={t} sink={sink} carDx={carDx} heads={t < 73.4} />
        {t > 76.6 && (
          <Character who="jharna" x={jx} y={1620} s={0.92} t={t} expr={t > 82.2 ? 'worried' : 'sheepish'} lean={pushing ? lean : 2} armL={armsY[0]} armR={armsY[1]} mud={mud} shake={pushing ? 1.5 : 0} />
        )}
        {t > 73.3 && (
          <Character who="yamin" x={yx} y={1640} s={1.0} t={t} expr={yExpr} talk={[R.s4y]} lean={lean} armL={armsY[0]} armR={armsY[1]} mud={mud} shake={pushing ? 2 : 0.6} />
        )}
        <Rain t={t} a={rainA} />
      </Shake>
      <AbsoluteFill style={{background: '#fff', opacity: flash * 0.9}} />
      <Stamp t={t} r={R.s4stamp} x={700} y={620} text="৩য় ঠেলা" color="#E5484D" />
      <Bubble t={t} r={R.s4y} tx={215} ty={1086} text="*আপনি*... *আপনি* ঠিক আছেন তো?" w={760} />
    </AbsoluteFill>
  );
};
