import React from 'react';
import {AbsoluteFill} from 'remotion';
import {R} from '../data';
import {kf, useT} from '../util';
import {Character} from '../components/Character';
import {TeaBG} from '../components/Backgrounds';
import {Bubble, Burst} from '../components/UI';

const OX = 540;
const OY = 1100;

export const Scene5: React.FC = () => {
  const t = useT();
  const z = kf(t, [91.9, 100.5, 103, 108, 116, 118.2], [1, 1.2, 1.2, 1, 1.12, 1.12], true);
  const P = (x: number, y: number): [number, number] => [OX + (x - OX) * z, OY + (y - OY) * z];

  // Jharna: stares -> bursts out laughing -> crouches with hands on waist -> talks -> rises
  const dy = kf(t, [98.4, 99.2, 107.4, 108.2], [0, 130, 130, 0], true);
  const jLaugh = t >= 95.88 && t < 116;
  const jExpr = t < 95.88 ? 'neutral' : t < 107.4 ? 'laugh' : 'smile';
  const jArms = t > 98.6 && t < 107.4 ? 55 : 4;
  const jShake = t > 95.88 && t < 107.3 ? 3 : 0;

  // Yamin: shocked -> looks at muddy hands -> laughs -> speaks
  const yExpr = t < 107.76 ? 'worried' : t < 112.28 ? 'sheepish' : t < 117 ? 'laugh' : 'smile';
  const yArms = t > 108.5 && t < 112.28 ? -35 : 4;
  const yShake = t >= 112.28 && t < 115.4 ? 3 : 0;

  const [jtx, jty] = P(780, 1700 + dy - 694 - 24);
  const [ytx, yty] = P(300, 1700 - 694 - 24);
  void jLaugh;

  return (
    <AbsoluteFill>
      <AbsoluteFill style={{transform: `scale(${z})`, transformOrigin: `${OX}px ${OY}px`}}>
        <TeaBG />
        <Character who="yamin" x={300} y={1700} s={1.3} t={t} expr={yExpr} mud={1} talk={[R.s5y]} armL={yArms} armR={yArms} shake={yShake} look={0.5} />
        <Character who="jharna" x={780} y={1700 + dy} s={1.3} t={t} expr={jExpr} mud={1} talk={[R.s5j]} armL={jArms} armR={jArms} shake={jShake} look={-0.4} />
      </AbsoluteFill>
      <Bubble t={t} r={R.s5j} tx={jtx} ty={jty} text="আমার চুলে *কাদা*, আপনার নাকে *কাদা*, আর আপনি এখনো *আপনি*?" w={900} />
      <Bubble t={t} r={R.s5y} tx={ytx} ty={yty} text="*তুমি*... *তুমি* ঠিক আছো তো, ঝর্ণা?" w={820} hl="#2F80ED" />
      <Burst t={t} s={116.0} x={540} y={1000} name="heart" n={8} />
    </AbsoluteFill>
  );
};
