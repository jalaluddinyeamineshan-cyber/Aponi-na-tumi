import React from 'react';
import {AbsoluteFill} from 'remotion';
import {R} from '../data';
import {inR, useT} from '../util';
import {Character} from '../components/Character';
import {CarBack, CarFront} from '../components/Backgrounds';
import {Bubble, FloatIcon, NoteCard} from '../components/UI';

export const Scene3: React.FC = () => {
  const t = useT();
  const out = t < 52.46 ? 'highway' : 'tea';
  const jWorried = t > 49;
  return (
    <AbsoluteFill>
      <CarBack t={t} out={out} />
      <Character who="yamin" x={300} y={1530} s={1.3} t={t} sit expr={t > 43.3 ? 'confident' : 'neutral'} talk={[[43.32, 46.9], R.s3y]} look={0.6} />
      <Character who="jharna" x={780} y={1530} s={1.3} t={t} sit expr={inR(t, R.s3j) || jWorried ? 'worried' : 'smile'} talk={[R.s3j]} look={t > 49 && t < 52 ? 0.9 : -0.5} />
      <CarFront />
      <FloatIcon t={t} r={[49.0, 52.46]} x={960} y={1180} name="phone" size={170} />
      <FloatIcon t={t} r={[55.78, 62.76]} x={960} y={1180} name="phone0" size={190} pulse />
      <NoteCard t={t} r={R.s3card} x={540} y={430} text="*৪০ মিনিট* বাঁচবে" icon="clock" iconP={0.2} w={720} />
      <Bubble t={t} r={R.s3j} tx={780} ty={810} text="একটু কাউকে *জিজ্ঞেস* করে নিলে হতো না?" />
      <Bubble t={t} r={R.s3y} tx={300} ty={810} text="না না, আমি *ঠিক চিনি।*" w={640} />
    </AbsoluteFill>
  );
};
