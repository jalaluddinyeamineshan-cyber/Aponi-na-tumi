import React from 'react';
import {AbsoluteFill} from 'remotion';
import {OUT} from '../data';
import {FONT} from '../fonts';
import {kf, Rich, sp, useT} from '../util';
import {SoftBG} from '../components/Backgrounds';
import {Burst} from '../components/UI';
import {Icon} from '../components/Icons';

const card = (k: number, extra?: React.CSSProperties): React.CSSProperties => ({
  position: 'absolute', left: 90, width: 900, boxSizing: 'border-box', padding: '40px 44px', background: '#fff',
  border: `4px solid ${OUT}`, borderRadius: 48, boxShadow: '0 14px 0 rgba(0,0,0,.14)', fontFamily: FONT, fontWeight: 700,
  fontSize: 64, lineHeight: 1.4, color: OUT, textAlign: 'center', transform: `scale(${k})`, opacity: Math.min(1, k * 2),
  ...extra,
});

export const Scene7: React.FC = () => {
  const t = useT();
  const aponi = kf(t, [159.6, 159.8, 161.0, 161.4], [0, 1, 1, 0]);
  const tumiK = sp(t, 161.14, {damping: 8, mass: 0.6});
  const nish = kf(t, [160.5, 160.7, 161.3, 161.6], [0, 1, 1, 0]);
  return (
    <AbsoluteFill>
      <SoftBG />
      <div style={{position: 'absolute', left: 0, right: 0, top: 130, display: 'flex', justifyContent: 'center', transform: `scale(${sp(t, 151.5)})`}}>
        <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 48, color: '#fff', background: '#E5484D', border: `4px solid ${OUT}`, borderRadius: 60, padding: '8px 40px'}}>
          আপনি থেকে তুমি
        </div>
      </div>
      <div style={card(sp(t, 151.7), {top: 290})}>
        <Rich text="কাছে আসতে সবসময় *সঠিক রাস্তা* লাগে না।" hl="#E5484D" />
      </div>
      <div style={card(sp(t, 155.0), {top: 640, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10})}>
        <Icon name="route" size={170} />
        <div>
          <Rich text="কখনো একসাথে *ভুল রাস্তায়* হারিয়ে গিয়ে *কাদায়* আটকে গেলেই" hl="#E5484D" />
        </div>
      </div>
      {/* আপনি -> তুমি */}
      <div style={{position: 'absolute', left: 0, right: 0, top: 1280, height: 420, fontFamily: FONT, fontWeight: 700, textAlign: 'center'}}>
        <div style={{position: 'absolute', left: 0, right: 0, top: 40, fontSize: 190, color: '#8A8F98', opacity: aponi, transform: `scale(${0.7 + 0.3 * aponi})`, textDecoration: t > 160.9 ? 'line-through' : 'none'}}>
          আপনি
        </div>
        <div style={{position: 'absolute', left: 0, right: 0, top: 250, fontSize: 56, color: OUT, opacity: nish}}>
          নিঃশব্দে ↓
        </div>
        <div style={{position: 'absolute', left: 0, right: 0, top: 20, fontSize: 250, color: '#E5484D', opacity: Math.min(1, tumiK * 2), transform: `scale(${tumiK})`}}>
          তুমি
        </div>
      </div>
      <Burst t={t} s={161.2} x={540} y={1500} name="heart" n={9} dur={2.2} />
    </AbsoluteFill>
  );
};
