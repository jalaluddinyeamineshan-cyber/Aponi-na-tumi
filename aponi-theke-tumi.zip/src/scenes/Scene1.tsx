import React from 'react';
import {AbsoluteFill} from 'remotion';
import {R} from '../data';
import {useT} from '../util';
import {Character} from '../components/Character';
import {CarBack, CarFront} from '../components/Backgrounds';
import {Bubble, FloatIcon, Stamp} from '../components/UI';

export const Scene1: React.FC = () => {
  const t = useT();
  const nod = t > 10.28 && t < 13 ? Math.sin(t * 6) * 3 : 0;
  return (
    <AbsoluteFill>
      <CarBack t={t} out="city" />
      <Character who="yamin" x={300} y={1530} s={1.3} t={t} sit expr={t < 4.6 ? 'sheepish' : 'worried'} talk={[R.s1y]} look={0.8} />
      <Character who="jharna" x={780} y={1530} s={1.3} t={t} sit expr="smile" talk={[R.s1j]} look={-0.5} lean={nod} />
      <CarFront />
      <FloatIcon t={t} r={[0.7, 2.98]} x={470} y={1170} name="bottle" size={190} rot={12} />
      <Bubble t={t} r={R.s1y} tx={300} ty={810} text="*আপনি* কি একটু পানি খাবেন?" />
      <Bubble t={t} r={R.s1j} tx={780} ty={810} text="না, ধন্যবাদ।" w={560} />
      <Stamp t={t} r={R.s1stamp} x={540} y={520} text="৩য় বার!" color="#E5484D" />
    </AbsoluteFill>
  );
};
