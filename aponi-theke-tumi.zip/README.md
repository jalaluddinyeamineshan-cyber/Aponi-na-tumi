# আপনি থেকে তুমি — Remotion project (1080x1920, 30fps, 4883 frames)

npm install
npx remotion studio
npx remotion render AponiTheke out/video.mp4

Audio: public/voice.mp3  |  SRT reference: public/voice.srt
